﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace GetOilPriceTrend
{
    class Program
    {

        public class Data
        {
            [JsonProperty("Date")]

            public DateTime dateISO8601 { get; set; }

            [JsonProperty("Price")]
            public double price { get; set; }
        }



        static void Main(string[] args)
        {
            DateTime start = new DateTime();
            DateTime end = new DateTime();
            try
            {

                 start = Convert.ToDateTime(Console.ReadLine());

                 end = Convert.ToDateTime(Console.ReadLine());
                GetOilPriceTrend(start, end);

            }
            catch(Exception ex)
            {
                Console.WriteLine("Inserire date in formato valido");
            }

            
            Console.ReadLine();
        }


        public static void GetOilPriceTrend(DateTime startDateISO8601, DateTime endDateISO8601)
        {
            try
            {
                using (WebClient wc = new System.Net.WebClient())
                {
                    var json = wc.DownloadString("https://pkgstore.datahub.io/core/oil-prices/brent-daily_json/data/78b325d2b9b2be78282cfd9f62978149/brent-daily_json.json");
                    var listOfTanks = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Data>>(json);
                    var returnValues = listOfTanks.Where(x => x.dateISO8601 >= startDateISO8601 && x.dateISO8601 <= endDateISO8601);
                    var output = JsonConvert.SerializeObject(returnValues);
                    Console.Write(output);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }


        }

    }
}
